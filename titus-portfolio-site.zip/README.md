# Titus Mukabana — Portfolio

This repository hosts my developer portfolio for **GitHub Pages**.

## Live URL
After you enable Pages (instructions below), your site will be available at:

- `https://<your-github-username>.github.io/` (if the repo is named `<your-github-username>.github.io`), **or**
- `https://<your-github-username>.github.io/portfolio/` (if the repo is named `portfolio`).

## What’s inside
- `index.html` — The portfolio page (edit text, links, and project cards)
- `styles.css` — Minimal, clean styles using system fonts
- `assets/Titus_Mukabana_CV.pdf` — Your resume PDF (replace with a newer version any time)

## Quick Edit
Search for **`your-github-username`** and replace with your handle. Update project links to real repos.

## Deploy to GitHub Pages
1. Create a public repo on GitHub (e.g., `portfolio` or `<your-github-username>.github.io`).  
2. Upload these files (drag & drop in the web UI or push via Git).  
3. Go to **Settings → Pages**.  
4. Under **Build and deployment**, set **Source: Deploy from a branch**.  
5. **Branch:** `main` and **Folder:** `/ (root)` → **Save**.  
6. Wait a minute for Pages to build, then open the URL shown there.

## Updating
Edit files and commit/push. Pages updates automatically.

---

Made with ❤️ in Nairobi, Kenya.
